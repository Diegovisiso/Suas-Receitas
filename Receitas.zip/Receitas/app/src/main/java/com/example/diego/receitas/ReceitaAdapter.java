package com.example.diego.receitas;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.diego.receitas.dominio.entidades.Receita;

import java.util.List;

/**
 * Created by diego on 22/11/2017.
 */

public class ReceitaAdapter extends RecyclerView.Adapter<ReceitaAdapter.ViewHolderReceita> {

    private List<Receita> dados;

    public ReceitaAdapter(List<Receita> dados){
        this.dados = dados;
    }

    @Override
    public ReceitaAdapter.ViewHolderReceita onCreateViewHolder(ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.list_receita, parent, false);

        ViewHolderReceita holderReceita = new ViewHolderReceita(view);

        return holderReceita;
    }

    @Override
    public void onBindViewHolder(ReceitaAdapter.ViewHolderReceita holder, int position) {

        if(dados != null && (dados.size() > 0) ) {

            Receita receita = dados.get(position);

            holder.txtNome.setText(receita.nomereceita);
            holder.txtServeQuantas.setText(receita.servequantas);
        }

    }

    @Override
    public int getItemCount() {

        return dados.size();
    }

    public class ViewHolderReceita extends RecyclerView.ViewHolder{

        public TextView txtNome;
        public TextView txtServeQuantas;

        public ViewHolderReceita(View itemView) {
            super(itemView);

            txtNome = (TextView) itemView.findViewById(R.id.txtNome);
            txtServeQuantas = (TextView) itemView.findViewById(R.id.txtServeQuantas);
        }
    }
}
