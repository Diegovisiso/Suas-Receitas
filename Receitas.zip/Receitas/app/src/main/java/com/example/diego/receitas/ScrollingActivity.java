package com.example.diego.receitas;

import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.example.diego.receitas.database.DadosOpenHelper;
import com.example.diego.receitas.dominio.entidades.Receita;
import com.example.diego.receitas.dominio.repositorio.ReceitaRepositorio;

import java.util.List;

public class ScrollingActivity extends AppCompatActivity {

    private NestedScrollView layoutContentMain;
    private SQLiteDatabase conexao;
    private DadosOpenHelper dadosOpenHelper;

    private ReceitaRepositorio receitaRepositorio;
    private RecyclerView lstDados;

    private ReceitaAdapter receitaAdapter;



    private void criarConexao(){
        try{

            dadosOpenHelper = new DadosOpenHelper(this);

            conexao = dadosOpenHelper.getWritableDatabase();

            Snackbar.make(layoutContentMain, "Conexão criada com sucesso!", Snackbar.LENGTH_SHORT)
                    .setAction("Ok", null).show();

        }catch (SQLException ex){

            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
            dlg.setTitle("Erro");
            dlg.setMessage(ex.getMessage());
            dlg.setNeutralButton("Ok",null);
            dlg.show();

        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrolling);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent( ScrollingActivity.this, cadActivity.class);
                        startActivity(it);
            }
        });

        //lstDados = (RecyclerView)findViewById(R.id.lstDados);
        layoutContentMain = (NestedScrollView) findViewById(R.id.layoutContentMain);
        criarConexao();

        //LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        //lstDados.setLayoutManager(linearLayoutManager);

        //receitaRepositorio = new ReceitaRepositorio(conexao);

        //List<Receita> dados  = receitaRepositorio.buscartodos();

        //receitaAdapter = new ReceitaAdapter(dados);

        //lstDados.setAdapter(receitaAdapter);

    }





}
