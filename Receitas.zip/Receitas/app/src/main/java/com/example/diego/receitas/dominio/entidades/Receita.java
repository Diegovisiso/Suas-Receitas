package com.example.diego.receitas.dominio.entidades;

/**
 * Created by diego on 21/11/2017.
 */

public class Receita {

    public int codigo;
    public String nomereceita;
    public String servequantas;
    public String tempopreparo;
    public String ingredientes;
    public String modopreparo;

}
